/** Testing entry point: production-adapter inputs and separately labelled normalized consumer fixtures. */
import type { ActorReference, ActorSnapshot, Codec, Contribution, ContributionId, ExecutionProvenance,
  IdentityKey, OperationId, PersonReference, Result, Scheduler,
  SessionStamp } from './model.js';
import type { IdentityHost, UpstreamDriver } from './host.js';
import type { ConnectionHealth, IdentityClientTransport, IdentityConnection, IdentityConnectionEvent } from './client.js';
import type { AtomicStateStorage, StateAddress, StateEnvelope, StateRead, StateVersion } from './state.js';
export interface ManualClock extends Scheduler {
  advance(milliseconds: number): Promise<void>;
  flush(): Promise<void>;
  readonly pendingTimers: number;
}
export interface Deferred<T> { readonly promise: Promise<T>; resolve(value: T): void; reject(reason: unknown): void; }
export declare function createManualClock(initialMilliseconds?: number): ManualClock;
export declare function deferred<T>(): Deferred<T>;
/** Person fixture is for multi-person scenarios. Singleton comes only from the instance's reserved default. */
export declare function personFixture(input: { readonly subject: string; readonly name: string }): ActorSnapshot & { readonly identity: PersonReference };
export interface FakeRequest { readonly id: string; readonly origin: 'interactive-user' | 'agent' | 'background' | 'external' | 'unauthenticated'; }
export interface FakeToolCall { readonly id: string; }
export interface Pause { readonly reached: Promise<void>; release(): void; }
export interface AdapterHarness<Input> {
  readonly upstream: UpstreamDriver<FakeRequest, FakeToolCall, Input>;
  readonly clock: ManualClock;
  /** Production inspectForkExtension and createHostAdapter path, not a supplied normalized host. */
  connect(): IdentityHost<FakeRequest, FakeToolCall, Input>;
  setRawExtension(value: unknown): void;
  /** @throws This adapter fixture does not model operation lookup controls. */
  setLookup(status: 'supported' | 'unsupported' | 'pending' | 'absent-final' | 'expired' | 'unavailable'): void;
  request(origin?: FakeRequest['origin']): FakeRequest;
  /** Multi-user replacement advances the session stamp and invalidates every issued request; singleton rejects it. */
  setActor(actor: ActorSnapshot & { readonly identity: ActorReference }): Result<void>;
  setIdentityAvailability(status: 'ready' | 'unavailable' | 'unauthenticated'): void;
  settle(request: FakeRequest): void;
  /** @throws Streaming is not modeled by this adapter fixture. */
  constructStreamingResponse(request: FakeRequest): void;
  /** @throws Streaming is not modeled by this adapter fixture. */
  finishStream(request: FakeRequest): void;
  abort(request: FakeRequest): void;
  replaceProvider(result: 'succeed' | 'fail'): void;
  disconnect(): void;
  reconnect(): void;
  /** @throws Acceptance pause points are not modeled by this adapter fixture. */
  pauseAcceptance(point: 'before-dispatch' | 'before-commit' | 'after-commit-before-response'): Pause;
  /** @throws Response loss is not modeled by this adapter fixture. */
  loseNextAcceptanceResponse(): void;
  /** @throws Causal contribution/attempt controls are not modeled by this adapter fixture. */
  beginAttempt(groups: readonly (readonly ContributionId[])[]): string;
  editContribution(id: ContributionId, editor: ActorSnapshot): void;
  continueAttempt(attemptId: string, reason: string): string;
  toolCallForAttempt(attemptId: string): FakeToolCall;
  /** @throws Causal contribution/attempt controls are not modeled by this adapter fixture. */
  readonly accepted: readonly Contribution[];
  readonly observations: { readonly submissions: number; readonly rawExtensionReads: number;
    readonly profileReads: number; readonly participantReads: number; readonly subscriptions: number };
  dispose(): void;
}
export declare function createAdapterHarness<Input>(options: {
  readonly mode: 'single-user' | 'multi-user';
  /** Plain fixture IDs are validated and branded inside the test runtime. */
  readonly instanceId?: string; readonly pluginId?: string;
  readonly inputCodec: Codec<Input>; readonly clock?: ManualClock;
}): AdapterHarness<Input>;
/** Unit-only shortcut, intentionally not evidence of host causal attribution correctness. */
export declare function consumerProvenanceFixture(provenance: ExecutionProvenance): FakeToolCall;
/** Raw connection controls exercise production decoder/health paths, not a pre-normalized client.
 * `state` and `identity` health can change independently so a state-only outage is reproducible.
 */
export interface ConnectionHarness {
  readonly connection: IdentityConnection;
  /** Exercises production createIdentityClientTransport and createStateTransport paths. */
  connect(): IdentityClientTransport;
  setHealth(health: ConnectionHealth): void;
  replyNext(method: string, payload: unknown): void;
  emit(event: IdentityConnectionEvent): void;
  pauseNextRequest(method: string): Pause;
  readonly observations: { readonly methods: readonly string[]; readonly disposeCalls: number };
}
export declare function createConnectionHarness(): ConnectionHarness;
export interface StateStorageHarness<T> {
  readonly storage: AtomicStateStorage<T>;
  seed(envelope: StateEnvelope<T>): void;
  seedEmpty(address: StateAddress, version: StateVersion): void;
  seedReadFailure(error: import('./model.js').IdentityError): void;
  seedLegacy(address: StateAddress, schemaVersion: number): void;
  readCommitted(address: StateAddress): StateEnvelope<T> | null;
  /** Snapshot timing is explicit to reproduce stale successful loads. */
  pauseNextRead(options: { readonly capture: 'before-pause' | 'after-release' }): Pause;
  pauseNextCommit(): Pause;
  loseNextCommitResponse(): void;
  expireReceipt(operationId: OperationId): void;
  readonly commits: readonly { readonly actor: IdentityKey; readonly address: StateAddress; readonly version: StateVersion }[];
}
export declare function createStateStorageHarness<T>(options: { readonly clock: ManualClock }): StateStorageHarness<T>;
