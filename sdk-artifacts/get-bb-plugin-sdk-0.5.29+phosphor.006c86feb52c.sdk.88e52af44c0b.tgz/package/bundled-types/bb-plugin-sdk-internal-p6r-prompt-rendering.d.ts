// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

interface P6rPromptContext {
    threadId?: string;
    projectId?: string;
    providerId?: string;
    sourcePluginId?: string;
}
interface P6rPromptSlot {
    token: string;
    text: string;
}
interface P6rPromptRequest {
    id: string;
    kind: "guide" | "instruction" | "message" | "schema-description" | "skill" | "template" | "tool-description" | "tool-result";
    text: string;
    template?: string;
    inputs?: Readonly<Record<string, string>>;
    context?: P6rPromptContext;
    slots?: readonly P6rPromptSlot[];
}
type P6rPromptMiddleware = (request: Readonly<P6rPromptRequest>, next: (text?: string) => string) => string;
interface P6rPromptObservation {
    request: Readonly<P6rPromptRequest>;
    defaultText: string;
    finalText: string;
    middleware: readonly {
        pluginId: string;
        name: string;
    }[];
    fallback?: {
        pluginId: string;
        name: string;
        reason: string;
    };
}

interface P6rPromptProvider {
    middleware(): readonly {
        pluginId: string;
        name: string;
        middleware: P6rPromptMiddleware;
    }[];
    observers(): readonly {
        pluginId: string;
        name: string;
        observer: (sample: P6rPromptObservation) => void;
    }[];
    warn(message: string): void;
}
declare function validateP6rPromptRequest(request: unknown): asserts request is P6rPromptRequest;
declare function createP6rPromptRenderer(getProvider: () => P6rPromptProvider | undefined): (request: P6rPromptRequest) => string;

export { createP6rPromptRenderer, validateP6rPromptRequest };
export type { P6rPromptProvider };
